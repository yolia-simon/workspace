// ==================================================
// JavaScript for the Counter Button Functionality
// ==================================================

// The DOMContentLoaded event ensures the script runs only after the page is fully loaded.
document.addEventListener("DOMContentLoaded", function () {
    // Get the button element by its ID
    const counterButton = document.getElementById("counterButton");
    // Get the span element that displays the counter number
    const counterDisplay = document.getElementById("counter");

    // Initialize a counter variable to zero
    let count = 0;

    // Add an event listener to the counter button that listens for clicks
    counterButton.addEventListener("click", function () {
        // Increase the counter variable by 1 each time the button is clicked
        count++;

        // Update the text inside the span to show the new count
        counterDisplay.textContent = count;
    });
});


// Note: Even if I have not shown it in the tutorrial, there should be a ; at the end of each statement in Javascript. 
